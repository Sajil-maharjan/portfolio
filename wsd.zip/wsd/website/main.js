
		function validateform(){
		var name = document.getElementById("name").value;
		var phone  = document.getElementById("phone").value;
		var email = document.getElementById("email").value;
		var message = document.getElementById("message").value;
		var invalid = document.getElementById("invalid");
		var text;

		invalid.style.padding="10px";

		if(name.length <5){
			text="please enter valid name";
			invalid.innerHTML = text;
			return false;
		}
		if(isNan(phone)||phone.length !=10){
			text="please enter valid number";
			invalid.innerHTML = text;
		
			return false;
		}
		if(email.indexof("@")==-1||email.length <6){
			text="please enter valid email";
			invalid.innerHTML = text;
			return false;
		}
		if(message.length <= 50){
			text="please enter valid message";
			invalid.innerHTML = text;
			return false;
					return false;

		}
		alert("form successfully submitted!")
		return true;
	}
